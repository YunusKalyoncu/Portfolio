export const config = {
  baseURL: 'https://lure-shop-react.herokuapp.com',
  products: '/products',
  pageSize: 10,
  advertIndex: 5,
  delay: 0,
  clientId:
    '90003418335-a9sv8077jr4ue96okgblus5r9fcqro1a.apps.googleusercontent.com',
};
