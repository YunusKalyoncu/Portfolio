import ProductDetails from './ProductDetails';

export default ProductDetails;
