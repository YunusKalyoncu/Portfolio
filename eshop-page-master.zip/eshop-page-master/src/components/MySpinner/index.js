import MySpinner from './MySpinner';

export default MySpinner;
